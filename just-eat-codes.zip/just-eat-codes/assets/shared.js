// assets/shared.js - small helper functions
function el(q){return document.querySelector(q)}
function elAll(q){return Array.from(document.querySelectorAll(q))}
function renderList(target, items){
  const out = items.map(i=>`<div class="card restaurant"><h4>${i.name}</h4><p class="small">${i.tagline}</p><p class="small">Entrega: ${i.delivery} • ${i.time} min</p><a class="btn" href="${i.link||'#'}">Ver</a></div>`).join('');
  el(target).innerHTML = out;
}
